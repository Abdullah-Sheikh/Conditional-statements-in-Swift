import UIKit

let name = "Abdullah"


// if conditions
if name.count > 7
{
    print ("Long Name")

}
else if name.count > 5
{
    print ("Medium Name")
}
else
{
    print("Short Name")
}


// switch statement

switch name.count
{
case 8 :
    print ("lenght 8")
    
case 8...20:
    print ("Long lenght")
    
default :
    print ("Some lenght")

}
